from django.db import models

# Create your models here.
class Audio(models.Model): 
    audio_file = models.FileField(null=True)