import speech_recognition as sr
from googletrans import Translator 
from elevenlabs import voices, clone, generate, play, set_api_key 

set_api_key("fe29f10daf678940d146dfb424140ccb")

def speech_to_text():
    # Initialize the recognizer
    recognizer = sr.Recognizer()

    while True: 

        # Capture audio from the microphone
        with sr.Microphone() as source:
            print("Say something:")
            audio_stream = recognizer.listen(source, timeout=None)

        try:
            # Use Google Web Speech API to convert speech to text
            # Set show_all to True to get multiple hypotheses with confidence scores
            result = recognizer.recognize_google(audio_stream, show_all=True)

            if "alternative" in result:
                # Extract the best transcription with the highest confidence
                best_transcription = max(result["alternative"], key=lambda x: x.get("confidence", 0))
                text = best_transcription["transcript"]
                print("You said:", text)

                # Save the text to a file
                save_to_file(text)
                translate_and_save(text) 

                # Keyword is 'stop' to prevent further translation
                if "stop" in text.lower(): 
                    break 
            else:
                print("No transcription available")

        except sr.UnknownValueError:
            print("Could not understand audio")

def save_to_file(text):
    with open("speech_to_text_output.txt", "w") as file:
        file.write(text + "\n")

def translate_and_save(text, target_language='es'): 
    translator = Translator() 
    translated_text = translator.translate(text, dest=target_language).text 

    with open("speech_to_text_output.txt", "a") as file:
        file.write("Translated Text: " + translated_text + "\n")

    voice_list = voices() 

    audio = generate(
        text=translated_text, 
        # Select trained voice 
        voice=voice_list[-1],
        model="eleven_multilingual_v2"
        )

    play(audio) 

if __name__ == "__main__":
    speech_to_text()

"""
voices = voices() 
print(voices) 
""" 