from django.urls import path
from . import views 

urlpatterns = [ 
    path('register/',views.register, name='register'),
    path('login/',views.login_view, name='login'),
    path('dashboard/',views.dashboard, name='dashboard'),
    path('meeting/',views.videocall, name='meeting'),
    path('logout/',views.logout_view, name='logout'),
    path('join/',views.join_room, name='join'),
    path('record/',views.record_voice,name='record'), 
    path('execute_script_es/',views.execute_script_es,name='execute_script_es'), 
    path('execute_script_en/',views.execute_script_en,name='execute_script_en'), 
    path('execute_script_fr/',views.execute_script_fr,name='execute_script_fr'), 

    path('',views.index, name='index'),
]